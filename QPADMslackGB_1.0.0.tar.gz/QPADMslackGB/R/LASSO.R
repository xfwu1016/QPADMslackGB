#' @title LASSO
#' @description The proximal operator of LASSO
#' @param lambda The tuning parameter for the  penalty
#' @param eta The constant for the proximal operators of the penalty
#' @param bb The constant vectors in the proximal operator
#' @return The solution for the proximal operator of LASSO
#' @export
LASSO<-function(lambda,eta,bb)
{ beta_k<-rep(0,length(bb))
for(i in 1:length(bb)){
  beta_k[i]<-sign(bb[i])*max(0,abs(bb[i])-lambda/eta)}
return(beta_k)
}