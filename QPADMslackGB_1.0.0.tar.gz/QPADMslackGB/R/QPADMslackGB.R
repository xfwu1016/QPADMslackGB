#' @title QPADMslackGB
#' @description Gaussian back substitution QPADMslack algorithm
#' @param Pen 'LASSO' or 'SCAD' or 'MCP'.
#' @param lam  Parameter tuning or regularization term parameters
#' @param X Matrix of predictors, of dimension (n*p); each row is an observation
#' @param y Response variable
#' @param tau The quantile level τ and the value must be in (0,1)
#' @param M The number of local machines
#' @returns \item{beta_u}{Regression coefficient.}
#' @returns \item{K}{number of iterations.}
#' @returns \item{t}{calculation time.}
#' @export
#' @examples
#' ####### regression model
#' n <- 30000
#' p <- 1000
#' rho <- .5
#' beta_true = rep(0, p)
#' beta_true[6] = beta_true[12] = beta_true[15] = beta_true[20] = 1
#' R <- matrix(0,p,p)
#' for(i in 1:p){
#'  for(j in 1:p){
#'    R[i,j] <- rho^abs(i-j)
#'  }
#'}
#' X <- matrix(rnorm(n*p),n,p) %*% t(chol(R))
#' X[,1] = pnorm(X[,1])
#' tau=0.7
#' e = rnorm(n)
#' y = X[,6]+X[,12]+X[,15]+X[,20]+0.7*X[,1]*e
#' beta_true[1] = 0.7*qnorm(tau)
#' modelslack=QPADMslackGB(X,y,Pen = "SCAD",lam=1200*sqrt(log(p)/n),tau=0.7,M=1) #
#' modelslack$beta_u[c(1,6,12,15,20)]
#' modelslack$K
#' modelslack$t
#' length(which(abs(modelslack$beta_u)>10^-4))
#' AE = sum(abs(modelslack$beta_u - beta_true))
#' AE      
#' ####### classification model
#' n=5000
#' p=2000
#' q=10
#' rho <- 0.5 #Can be adjusted to 0.2, 0.4, 0.6
#' #First class
#' x1 <- matrix(rnorm(n*q,0,1), n, q)
#' x2 <- matrix(rnorm(n*(p-q),0,1), n, p-q)
#' corrmat1 <- toeplitz(rho^(0:(q-1)))
#' corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
#' X_1 <- cbind(x1%*% chol(corrmat1)+1, x2%*% chol(corrmat2))
#' #Second class
#' x1 <- matrix(rnorm(n*q,0,1), n, q)
#' x2 <- matrix(rnorm(n*(p-q),0,1), n, p-q)
#' corrmat1 <- toeplitz(rho^(0:(q-1)))
#' corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
#' X_2 <- cbind(x1%*% chol(corrmat1)-1, x2%*% chol(corrmat2))
#' ##Data preparation
#' X0= rbind(X_1,X_2)
#' X0 = cbind(matrix(1,nrow=2*n,1),X0)
#' y_label=c(rep(1,n),rep(-1,n))

#' ##Test dataset
#' nt=500
#' #First class
#' x1 <- matrix(rnorm(nt*q,0,1), nt, q)
#' x2 <- matrix(rnorm(nt*(p-q),0,1), nt, p-q)
#' corrmat1 <- toeplitz(rho^(0:(q-1)))
#' corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
#' X_1 <- cbind(x1%*% chol(corrmat1)+1, x2%*% chol(corrmat2))
#' #Second class
#' x1 <- matrix(rnorm(nt*q,0,1), nt, q)
#' x2 <- matrix(rnorm(nt*(p-q),0,1), nt, p-q)
#' corrmat1 <- toeplitz(rho^(0:(q-1)))
#' corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
#' X_2 <- cbind(x1%*% chol(corrmat1)-1, x2%*% chol(corrmat2))
#' X0t = rbind(X_1,X_2)
#' X0t = cbind(matrix(1,nrow=2*nt,1),X0t)
#' yt_label=c(rep(1,nt),rep(-1,nt))
#' n = nrow(X0)
#' p = ncol(X0)
#' y = rep(1,n)
#' X = diag(y_label)%*%X0 
#' SVMmodel=QPADMslackGB(X,y,Pen = "SCAD",lam=200*sqrt(log(p)/n),tau=0.7,M=1)
#' (SVMmodel$beta_u[1:11])/(SVMmodel$beta_u[2])
#' SVMmodel$K
#' SVMmodel$t
#' length(which(abs(SVMmodel$beta_u)>10^-4))
#' #Training set prediction accuracy
#' length(which((sign(X0%*%SVMmodel$beta_u))  - y_label==0))/n
#' # Test set prediction accuracy
#' length(which((sign(X0t%*%SVMmodel$beta_u))  - yt_label==0))/(2*nt)
QPADMslackGB<- function(X,y,Pen,lam,tau,M){
  if(Pen=="LASSO"){PEN = LASSO}else if(Pen=="MCP"){PEN = MCP}else{PEN = SCAD}
  begint <- proc.time()
  n = nrow(X)
  p = ncol(X)
  ite = 500
  gam = 10^1
  nu = 0.999
  #M = 1
  #m=1
  beta_0=matrix(0.01,p,1) #old
  beta_u=matrix(0.01,p,1) #new
  betaM=matrix(0.01,p,M)
  betaU=matrix(0.01,p,M)
  r1M=matrix(0.01,n/M,M)
  r1U=matrix(0.01,n/M,M)
  r2M=matrix(0.01,n/M,M)
  r2U=matrix(0.01,n/M,M)
  uM=matrix(0.01,p,M)
  uU=matrix(0.01,p,M)
  vM=matrix(0.01,n/M,M)
  vU=matrix(0.01,n/M,M)
  group <- list()
  Inv_array <- array(0, dim=c(p, p, M))
  for (aa in 1:M) {
    group[[aa]] <- (1:n)[(n/M*(aa-1)+1) : (n/M*aa)]
  }
  
  for (aa in 1:M) {
    Inv_array[,,aa] = X_inv(X[group[[aa]],])
  }
  
  
  k=0
  repeat{
    bb = rowMeans(betaM) + rowMeans(uM)/gam
    beta_u=PEN(lam,gam*M,bb)
    time=rep(0,M)
    for (m in 1:M) {
      begin <- proc.time()
      r1U[,m] = pos(y[group[[m]]] - X[group[[m]],]%*%betaM[,m] + r2M[,m] + (vM[,m]-tau)/gam) 
      r2U[,m] = pos(-y[group[[m]]]+ X[group[[m]],]%*%betaM[,m] + r1U[,m] - (vM[,m] + 1 - tau)/gam) 
      bbm = t(X[group[[m]],])%*%(y[group[[m]]] -  r1U[,m] + r2U[,m] + vM[,m]/gam)- (uM[,m])/gam + beta_u
      betaU[,m] = Inv_array[,,m]%*%bbm  ####需要矩阵求逆
      uU[,m] =   uM[,m] + gam*(betaM[,m] - beta_u)
      vU[,m] =   vU[,m] + gam*(y[group[[m]]] - X[group[[m]],]%*%betaU[,m] -  r1U[,m] + r2U[,m])
      r2U[,m] = (1-nu)* r2M[,m] + nu*r2U[,m] - nu*X[group[[m]],]%*%(betaM[,m] - betaU[,m])  #校正
      betaU[,m] = (1-nu)* betaM[,m] + nu*betaU[,m]
      end <- proc.time()
      time[m]=(end-begin)[3]
    }
    Perror=sqrt(sum((beta_u-beta_0)^2))/max(1,sqrt(sum(beta_0^2)))
    if(((Perror<5*10^-3)&(k>20))|(k>ite-1)){break}
    beta_0 = beta_u
    betaM = betaU
    r1M = r1U
    r2M = r2U
    uM = uU
    vM = vU
    k = k + 1
  }
  endt <- proc.time()
  Tol=endt-begint
  result=list(beta_u=beta_u,K=k,t = Tol[3] - sum(time)+max(time))
  return(result)
}