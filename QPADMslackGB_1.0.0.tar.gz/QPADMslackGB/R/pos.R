#' @title pos
#' @description Compare the elements in a vector with zero and take their maximum value
#' @param x Input vector
#' @return Output vector after implementing positive operation
pos<-function(x)
{
  xx=rep(0,length(x))
  for (i in 1:length(x)) {
    xx[i] = max(0,x[i])
  }
return(xx)
}