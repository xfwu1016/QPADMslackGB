#' @title SCAD
#' @description The proximal operator of SCAD
#' @param lambda The tuning parameter for the  penalty
#' @param eta The constant for the proximal operator of the penalty
#' @param bb The constant vector in the proximal operator
#' @return The solution for the proximal operator of SCAD
#' @export
SCAD<-function(lambda,eta,bb){
  a = 3.7
  beta_k=rep(0, length(bb))
  for (i in 1:length(bb)) {
    if(abs(bb[i])<lambda*(1+1/eta)){beta_k[i]=sign(bb[i])*max(abs(bb[i])-
        lambda/eta,0)}else if(abs(bb[i])>a*lambda){beta_k[i] = bb[i]}else{
        beta_k[i] = sign(bb[i])*((a-1)*eta*abs(bb[i])-a*lambda)/((a-1)*eta-1)
        }
  }
return(beta_k)
}
