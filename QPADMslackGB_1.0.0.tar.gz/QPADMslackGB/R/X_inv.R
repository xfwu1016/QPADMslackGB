#' @title X_inv
#' @description The Woodbury matrix identity for the inverse of a matrix
#' @param X Matrix of predictors, of dimension (n*p); each row is an observation
#' @return The inverse of the matrix (t(X)X+I_p)
#' @export
X_inv<-function(X){
  n=nrow(X)
  p=ncol(X)
  XX=matrix(0,p,p)
  if(n>=p){H = t(X)%*%X+ diag(1,p)
  Hc=chol(H)
  XX =chol2inv(Hc)}else{
    H = X%*%t(X)+ diag(1,n) 
    Hc=chol(H)
    XX = diag(1,p) - t(X)%*%chol2inv(Hc)%*%X
  }
  return(XX)
}